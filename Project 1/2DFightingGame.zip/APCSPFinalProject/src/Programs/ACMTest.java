package Programs;
import java.awt.Graphics;

import acm.program.GraphicsProgram;
public class ACMTest  {

	public static void main(String[] args) {
		//ExampleStickFighter n = new ExampleStickFighter()
		//n.init();
		//n.start();
		//new Battle().start(args);
		System.out.println("Hey");
	}

}
